#include <algorithm>
#include <cctype>
#include <climits>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;


//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

const unsigned int DEFAULT_SIZE = 150;

struct Course {
    string courseId;
    string courseName;
    string prereqs = "";
};


//============================================================================
// Hash Table class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a hash table with chaining.
 */

class HashTable {

private:
    // Define structures to hold courses
    struct Node {
        Course course;
        unsigned int key;
        Node *next;

        // default constructor
        Node() {
            key = UINT_MAX;
            next = nullptr;
        }

        // initialize with a course
        Node(Course aCourse) : Node() {
            course = aCourse;
        }

        // initialize with a course and a key
        Node(Course aCourse, unsigned int aKey) : Node(aCourse) {
            key = aKey;
        }
    };

    vector<Node> nodes;

    unsigned int tableSize = DEFAULT_SIZE;

    unsigned int keyGen(string key);

public:
    HashTable();
    HashTable(unsigned int size);
    virtual ~HashTable();
    void insertCourse(Course course);
    void printCourseList();
    void findCourse(string userInput);
};

/**
 * Default constructor
 */
HashTable::HashTable() {
    // Initalize node structure by resizing tableSize
    nodes.resize(tableSize);
}

/**
 * Constructor for specifying size of the table
 * Use to improve efficiency of hashing algorithm
 * by reducing collisions without wasting memory.
 */
HashTable::HashTable(unsigned int size) {
    // retrieves local size value and sets it equal to tableSize
    this->tableSize = size;
    // resizes hash table
    nodes.resize(size);
}

/**
 * Destructor
 */
HashTable::~HashTable() {
    // erase nodes beginning
    nodes.erase(nodes.begin());
}

/**
 * Calculate the hash value of a given key.
 * Note that key is specifically defined as
 * unsigned int to prevent undefined results
 * of a negative list index.
 *
 * @param key The key to hash
 * @return The calculated hash
 */
unsigned int HashTable::keyGen(string key) {

    unsigned StringHash = 0;

    // loop that multiplies each char's ASCII value in key by 3,
    // then adds the key value to it.
    for (unsigned i = 0; i < key.length(); i++) {
        StringHash = StringHash * 3 + key[i];
    }

    // uses the result of StringHash to take the mod of tableSize,
    // then returns the result.
    return StringHash % tableSize;
}

/**
 * Loads the file and calls insertCourse for the HashTable.
 *
 * @param filePath The file that contains courses
 * @param ht The HashTable that stores all nodes
 */
void loadFile(string filePath, HashTable* ht) {

    ifstream courseFile;
    
    courseFile.open(filePath);

    // loop that assigns values to courses
    if (courseFile.is_open()) {

        string line;
        string word;
        string tempVal;
        vector<string> tempVector;

        // while there are more lines in the file
        while (getline(courseFile, line)) {
            Course course;
            // finds comma in line, sets result equal to courseId,
            // then erases the word.
            size_t pos = line.find(",");
            course.courseId = line.substr(0, pos);
            line.erase(0, pos + 1);
            // finds comma in line, sets result equal to courseName,
            // then erases the word.
            pos = line.find(",");
            course.courseName = line.substr(0, pos);
            line.erase(0, pos + 1);
            // sets prereqs equal to the the remaining (if any) string.
            if (!line.empty()) {
                course.prereqs = line;
            }
            ht->insertCourse(course);
        }
        courseFile.close();
        cout << "Data loaded successfully." << endl;
    }
    else {
        cout << "Error opening file." << endl;
    }
}

/**
 * Inserts a course
 *
 * @param course The created course from loadFile
 */
void HashTable::insertCourse(Course course) {
    
    // create the key for the given bid
    unsigned tempKey = keyGen(course.courseId);
    // retrieve node using key
    Node* tempNode = &(nodes.at(tempKey));

    // if no entry found for the key
    if (tempNode == nullptr) {
        // assign this node to the key position
        Node* newNode = new Node(course, tempKey);
        nodes.insert(nodes.begin() + tempKey, (*newNode));
    }
    // else if node is not used
    else if (tempNode->key == UINT_MAX) {
        // assigns values to node and nullptr to next pointer
        tempNode->key = tempKey;
        tempNode->course = course;
        tempNode->next = nullptr;
    }
    // else find the next open node
    else {
        while (tempNode->next != nullptr) {
            tempNode = tempNode->next;
        }
        // add new newNode to end
        tempNode->next = new Node(course, tempKey);
    }
}

/**
 * Print all courses
 */
void HashTable::printCourseList() {

    vector<string> tempVec;

    // inserts all courseId's from nodes into tempVec
    for (Node node : nodes) {
        if (!node.course.courseId.empty()) {
            tempVec.push_back(node.course.courseId);
        }
    }

    //alphanumerically sorts tempVec
    sort(tempVec.begin(), tempVec.end());

    cout << "Course list:" << endl;
    cout << endl;

    // outputs the courseId...
    for (string cId : tempVec) {
        cout << cId << ", ";
        // ...then uses it to find the matching courseId in nodes...
        for (Node node : nodes) {
            if (node.course.courseId == cId) {
                // ...and outputs the courseName that is in the same course.
                cout << node.course.courseName << endl;
                break;
            }
        }
    }
}

/**
 * Searches for the courseId input by user
 *
 * @param userInput The courseId to search for
 */
void HashTable::findCourse(string userInput) {

    string tempStr = "";

    // loop that concatenates userInput to tempStr and forces uppercase
    // on any lower, as the ASCII value changes between the two.
    for (unsigned int i = 0; i < userInput.length(); i++) {
        // if the chracter is a letter...
        if (isalpha(userInput.at(i))) {
            // ...concatenate it to tempStr, then uppercase
            tempStr += toupper(userInput.at(i));
        }
        // else, concatenate the char to tempStr without uppercase
        else {
            tempStr += userInput.at(i);
        }
    }
    // retrieves key using uppercase string
    int tempKey = keyGen(tempStr);

    // retrieve node using key
    Node* tempNode = &(nodes.at(tempKey));
    // if entry found for the key
    if (tempNode != nullptr && tempNode->key == tempKey) {
        // output courseId and courseName
        cout << tempNode->course.courseId << ", " << tempNode->course.courseName << endl;
        // if there are prereqs, output them - otherwise, output 'None'
        cout << "Prerequisites: ";
        if (tempNode->course.prereqs.at(0) == ',') {
            cout << "None." << endl;
        }
        else {
            cout << tempNode->course.prereqs << endl;
        }
        return;
    }
    // if no entry found for the key
    else if (tempNode == nullptr || tempNode->key == UINT_MAX) {
        // output '[CourseId] not found'
        cout << userInput << " not found." << endl;
    }
    // while node not equal to nullptr
    while (tempNode != nullptr) {
        // if the current node matches...
        if (tempNode->key == tempKey) {
            // output courseId and courseName
            cout << tempNode->course.courseId << ", " << tempNode->course.courseName << endl;
            // if there are prereqs, output them - otherwise, output 'None'
            cout << "Prerequisites: ";
            if (tempNode->course.prereqs.at(0) == ' ') {
                cout << "None." << endl;
            }
            else {
                cout << tempNode->course.prereqs << endl;
            }
            return;
        }
        //node is equal to next node
        tempNode = tempNode->next;
    }
}

int main()
{
    // Define a hash table to hold all courses
    HashTable* ht;
    ht = new HashTable();

    bool isTrue = true;
    string userChoice;
    string userInput;

    cout << "Welcome to the course planner." << endl;

    while (isTrue == true) {

        cout << endl;

        cout << "1. Load Data Structure" << endl;
        cout << "2. Print Course List" << endl;
        cout << "3. Print Course" << endl;
        cout << "9. Exit" << endl;

        cout << endl;

        cout << "What would you like to do? ";
        cin >> userChoice;

        if (userChoice == "1") {
            cout << "Please enter the file name (with extension). ";
            getline(cin >> ws, userInput);
            loadFile(userInput, ht);
        }
        else if (userChoice == "2") {
            ht->printCourseList();
        }
        else if (userChoice == "3") {
            cout << "Which course do you want to know about? ";
            cin >> userInput;
            ht->findCourse(userInput);
        }
        else if (userChoice == "9") {
            cout << "Thank you for using the course planner!" << endl;
            isTrue = false;
        }
        else {
            cout << userChoice << " is not a valid option." << endl;
        }

    }
}