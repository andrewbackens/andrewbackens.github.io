"""
Project name: CS-499 Capstone Project
Author: Andrew Backens
Date: 01/22/2026
Version 1.0
"""

import operator
import pprint
from dataclasses import dataclass
from typing import Optional
import csv


#############################################################
# Global definitions visible to all methods and classes
#############################################################


@dataclass
class Course:
    # Class that contains information about courses.
    course_id: str
    course_name: str
    prereqs: Optional[str]


#############################################################
# Methods used by the main function
#############################################################

def csv_to_dataclass(filepath):
    """
    Loads the course data from the file and creates a vector object to hold it.

    :param filepath: File path of the .csv file to be read from.
    :return: Returns the course list.
    """
    course_list = []
    try:
        # Establishes a read object to read data from file.
        with open(filepath, 'r', newline="") as read_obj:
            csv_reader = csv.reader(read_obj, delimiter=',')

            for row in csv_reader:
                try:
                    # Creates a new course object to hold data.
                    current_course = Course(
                        course_id=row[0],
                        course_name=row[1],
                        prereqs=row[2]
                    )
                    # Appends course to the course list.
                    course_list.append(current_course)

                except (KeyError, ValueError, AttributeError):
                    print(f"Error with row {row}.")

        return course_list

    # Throws an exception if the file will not open or is not found.
    except FileNotFoundError:
        print("File not found.")


def search_course(course_list):
    """
    Searches the course list for the course name or ID provided by the user.

    :param course_list: The list of courses from the file.
    :return: Nothing. Exists to break function.
    """
    # Forces the user's input to be uppercase to match the data.
    user_search = input("What is the course name or ID? ").upper()

    for current_course in course_list:
        # If the user's search matches the current course's ID or name...
        if user_search == current_course.course_id.upper() or user_search == current_course.course_name.upper():
            # ...print the course.
            print(current_course)
            return

    print("Course not found.")


def create_course():
    """
    Takes the user inputs for the course ID, name, and prerequisites (optional) and creates a new Course object.

    :return: Void function.
    """
    user_prereq_choice = ""

    # Forces the user's course ID to be uppercase to match the current data.
    user_course_ID = input("What is the course ID? ").upper()
    user_course_name = input("What is the course name? ")
    # Loop that forces the user to type 'no' or 'yes' to continue
    while user_prereq_choice.lower() != 'no' or user_prereq_choice.lower() != 'yes':
        user_prereq_choice = input("Are there any prerequisites? Yes/No ")
        if user_prereq_choice.lower() == 'no' or user_prereq_choice.lower() == 'yes':
            break
        else:
            print("That is not a valid choice.")
    if user_prereq_choice.lower() == 'yes':
        user_prereqs = input("What are the prerequisites? Enter each separated by a comma. ")
    # If there are no prerequisites, creates an empty string to be used when writing to file.
    else:
        user_prereqs = ""

    # Create a new list with the user's inputs.
    user_course = [user_course_ID, user_course_name, user_prereqs]
    try:
        # Create a csv writer with append functionality.
        with open(file_path, 'a', newline="") as write_obj:
            csv_writer = csv.writer(write_obj)
            # Writes the user's list to the next empty row.
            csv_writer.writerow(user_course)

    except (ValueError, KeyError, AttributeError):
        print("Error writing to file.")


def print_courses(course_list):
    """
    Sorts the course list alphanumerically, then prints the list for the user.

    :param course_list: The list of courses from the file.
    :return: Void function.
    """

    # Sorts the course list alphanumerically based on the course ID.
    sorted_course_list = sorted(course_list, key=operator.attrgetter('course_id'))

    pprint.pprint(sorted_course_list)


is_true = True
user_choice = ""
# File path for csv input.
file_path = 'CS 300 ABCU_Advising_Program_Input.csv'

# Loads the file for later use.
courses = csv_to_dataclass(file_path)

print("Welcome to the course planner.")
# Main menu loop. Only breaks when user inputs '9'.
while is_true:
    print("Main menu. Please input your choice as a number.")
    print("1. Display all courses")
    print("2. Display a single course")
    print("3. Add a course")
    print("9. Exit program")

    user_choice = input()
    if user_choice == '1':
        print_courses(courses)
    elif user_choice == '2':
        search_course(courses)
    elif user_choice == '3':
        create_course()
        # After the course is created, the file needs to be re-read to be updated.
        courses = csv_to_dataclass(file_path)
    elif user_choice == '9':
        print("Thank you for using the program. Goodbye.")
        is_true = False
