"""
Project name: CS-499 Capstone Project
Author: Andrew Backens
Date: 02/05/2026
Version 1.2
"""

import csv
import tkinter as tk
import pandas as pd
import pymongo
from pymongo import MongoClient

#############################################################
# Global definitions visible to all methods and classes
#############################################################

# File path for csv input.
file_path = 'CS 300 ABCU_Advising_Program_Input.csv'

# Establishes connection with the Mongo database
db = MongoClient()['course_db']

# Collection name for the Mongo database
col = db.courses


#############################################################
# Methods used by the main function
#############################################################

def csv_to_db(filepath):
    """
    Loads the data from the csv file and transfers it to the Mongo database.

    :param filepath: File path of the csv file to be read from.
    :return: Success message to print to GUI.
    """

    # Erases the collection in preparation for the csv data
    db.courses.drop()

    try:
        df = pd.read_csv(filepath)

        col.insert_many(df.to_dict('records'))

        return "Success! Remember to refresh the database when viewing it for the newest version."

    # Throws an exception if the file will not open or is not found.
    except FileNotFoundError:
        return "File not found."


def print_courses():
    """
    Sorts the course list alphanumerically, then returns the list for the GUI to display.

    :return: Alphanumerically sorted Course list.
    """

    # Sorts the course list alphanumerically based on the course ID.
    sorted_course_list = col.find({}, {"_id": 0}).sort("course_id", pymongo.ASCENDING)

    return sorted_course_list


def search_course(user_search):
    """
    Searches the course database for the course name or ID provided by the user.

    :param user_search: Input from the user's entry on the Search Course GUI frame.
    :return: If found, the course that matches the user's search. Otherwise, a string that it was not found.
    """

    # Check if the user's search matches any course ID or course name in the database
    search_course_id = col.find_one({"course_id": user_search.upper()}, {"_id": 0})
    search_course_name = col.find_one({"course_name": user_search}, {"_id": 0})

    # If the user's search matches either the ID or name, return the course.
    if search_course_id:
        return search_course_id
    elif search_course_name:
        return search_course_name
    else:
        return "Course not found."


def create_course(user_course_ID, user_course_name, user_prereqs):
    """
    Takes the user inputs for the course ID, name, and prerequisites (optional) and creates a new Course object.
    Writes Course to the file.

    :param user_course_ID: Input from the user's course ID entry on the Add Course GUI frame.
    :param user_course_name: Input from the user's course name entry on the Add Course GUI frame.
    :param user_prereqs: Optional. Input from the user's prerequisites entry on the Add Course GUI frame.
    :return: Message if there was success or failure writing the new Course to the file.
    """

    try:
        # Create a csv writer with append functionality.
        with open(file_path, 'a', newline="") as write_obj:
            csv_writer = csv.writer(write_obj)
            # Writes the user's list to the next empty row.
            csv_writer.writerow([user_course_ID, user_course_name, user_prereqs])
            return "Success! Remember to update the database to view your changes."

    except (ValueError, KeyError, AttributeError):
        return "Error writing to file."


######################################################################################################
# GUI application. Replaces the menu from previous program.

# Code adapted from https://stackoverflow.com/questions/7546050/switch-between-two-frames-in-tkinter.
######################################################################################################

class GUI(tk.Tk):
    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)

        # the container is where we'll stack a bunch of frames
        # on top of each other, then the one we want visible
        # will be raised above the others
        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for F in (MainFrame, DisplayCoursesFrame, SearchCourseFrame, AddCourseFrame):
            page_name = F.__name__
            frame = F(parent=container, controller=self)
            self.frames[page_name] = frame

            # put all the pages in the same location;
            # the one on the top of the stacking order
            # will be the one that is visible.
            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame("MainFrame")

    def show_frame(self, page_name):
        """Show a frame for the given page name"""
        frame = self.frames[page_name]
        frame.tkraise()


class MainFrame(tk.Frame):
    """
    Home frame of the GUI.
    """

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        label = tk.Label(self, text="Main Menu")
        label.pack(side="top", fill="x", pady=10)

        text_area = tk.Text(self, width=85, height=15)
        text_area.insert(tk.INSERT, "Remember to update the database before using it! Otherwise it will be blank.")

        display_button = tk.Button(self, text="Display all courses",
                                   command=lambda: controller.show_frame("DisplayCoursesFrame"))
        search_button = tk.Button(self, text="Search for a course",
                                  command=lambda: controller.show_frame("SearchCourseFrame"))
        add_button = tk.Button(self, text="Add a course",
                               command=lambda: controller.show_frame("AddCourseFrame"))

        csv_to_db_button = tk.Button(self, text="Import/Update Database",
                                     command=lambda: update_db())

        exit_button = tk.Button(self, text="Exit",
                                command=lambda: app.destroy())

        def update_db():
            text_area.delete("1.0", "end")
            text_message = csv_to_db(file_path)
            text_area.insert(tk.INSERT, text_message)

        display_button.pack()
        search_button.pack()
        add_button.pack()
        csv_to_db_button.pack()
        text_area.pack()
        exit_button.pack()


class DisplayCoursesFrame(tk.Frame):
    """
    GUI frame that runs the print_courses function to display all courses.
    """

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        tk.Label(self, text="All courses").pack(side="top", fill="x", pady=10)
        text_area = tk.Text(self, width=125, height=20)

        # Function that runs print_courses and loops through the list to display each Course.
        def insert_text():
            text_area.delete("1.0", "end")
            print_list = print_courses()

            for values in print_list:
                text_area.insert(tk.INSERT, values)
                text_area.insert(tk.INSERT, '\n')

        refresh_button = tk.Button(self, text="Refresh",
                                   command=lambda: insert_text())

        insert_text()

        text_area.pack()
        refresh_button.pack()

        tk.Button(self, text="Main menu",
                  command=lambda: controller.show_frame("MainFrame")).pack()


class SearchCourseFrame(tk.Frame):
    """
    GUI frame that takes the user's entry to run the search_course function.
    """

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        tk.Label(self, text="Search for a course").pack(side="top", fill="x", pady=10)
        user_entry = tk.Entry(self)
        text_area = tk.Text(self, width=100, height=10)

        # Function that erases the current text and inserts the search result
        def insert_text():
            text_area.delete("1.0", "end")
            search_result = search_course(user_entry.get())
            text_area.insert(tk.INSERT, search_result)

        search_button = tk.Button(self, text="Search",
                                  command=lambda: insert_text())

        user_entry.pack()
        search_button.pack()
        text_area.pack()

        tk.Button(self, text="Main menu",
                  command=lambda: controller.show_frame("MainFrame")).pack()


class AddCourseFrame(tk.Frame):
    """
    GUI frame that takes the user's inputs to run the create_course function and add it to the file.
    """

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        tk.Label(self, text="Add a course").pack(side="top", fill="x", pady=10)

        course_id_label = tk.Label(self, text="Course ID")
        course_name_label = tk.Label(self, text="Course Name")
        prereqs_label = tk.Label(self, text="Prerequisites (optional, separate each entry with a comma)")

        course_id_entry = tk.Entry(self)
        course_name_entry = tk.Entry(self)
        prereqs_entry = tk.Entry(self)

        text_area = tk.Text(self, width=100, height=5)

        # Function that takes all 3 entries and runs create_course to add the new course to the file
        def insert_course():
            text_area.delete("1.0", "end")
            # Checks if the entries are not empty
            if len(course_id_entry.get()) > 0 and len(course_name_entry.get()) > 0:
                result = create_course(course_id_entry.get(), course_name_entry.get(), prereqs_entry.get())
            else:
                result = "Course ID and name required."
            text_area.insert(tk.INSERT, result)

        add_button = tk.Button(self, text="Add course",
                               command=lambda: insert_course())

        course_id_label.pack()
        course_id_entry.pack()
        course_name_label.pack()
        course_name_entry.pack()
        prereqs_label.pack()
        prereqs_entry.pack()
        add_button.pack()
        text_area.pack()

        tk.Button(self, text="Main Menu",
                  command=lambda: controller.show_frame("MainFrame")).pack()


if __name__ == "__main__":
    app = GUI()
    app.title("Course Planner")
    app.mainloop()
